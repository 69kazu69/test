"use strict";

window.fwSettings = {
  'widget_id': 82000004694
};
!function () {
  if ("function" != typeof window.FreshworksWidget) {
    var n = function () {
      n.q.push(arguments);
    };

    n.q = [], window.FreshworksWidget = n;
  }
}();